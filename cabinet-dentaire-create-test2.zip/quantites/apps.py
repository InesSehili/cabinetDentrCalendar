from django.apps import AppConfig


class QuantitesConfig(AppConfig):
    name = 'quantites'
