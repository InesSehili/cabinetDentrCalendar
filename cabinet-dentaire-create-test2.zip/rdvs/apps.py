from django.apps import AppConfig


class RdvsConfig(AppConfig):
    name = 'rdvs'
