from django.apps import AppConfig


class AchatsConfig(AppConfig):
    name = 'achats'
