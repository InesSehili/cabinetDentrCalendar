from django.apps import AppConfig


class PayementsConfig(AppConfig):
    name = 'payements'
