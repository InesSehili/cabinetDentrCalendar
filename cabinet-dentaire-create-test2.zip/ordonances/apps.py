from django.apps import AppConfig


class OrdonancesConfig(AppConfig):
    name = 'ordonances'
