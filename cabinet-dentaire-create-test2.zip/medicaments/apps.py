from django.apps import AppConfig


class MedicamentsConfig(AppConfig):
    name = 'medicaments'
