from django.apps import AppConfig


class FichesmedicalConfig(AppConfig):
    name = 'fichesMedical'
