from django.apps import AppConfig


class TyperdvsConfig(AppConfig):
    name = 'typerdvs'
