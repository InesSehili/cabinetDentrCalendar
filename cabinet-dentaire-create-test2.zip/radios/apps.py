from django.apps import AppConfig


class RadiosConfig(AppConfig):
    name = 'radios'
