from django.apps import AppConfig


class FournisseursConfig(AppConfig):
    name = 'fournisseurs'
