from django.apps import AppConfig


class ConsultationsConfig(AppConfig):
    name = 'consultations'
