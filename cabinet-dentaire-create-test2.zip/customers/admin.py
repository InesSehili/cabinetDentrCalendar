from django.contrib import admin

from customers.models import Profile

admin.site.register(Profile)
