from django.apps import AppConfig


class DiagnostiquesConfig(AppConfig):
    name = 'diagnostiques'
