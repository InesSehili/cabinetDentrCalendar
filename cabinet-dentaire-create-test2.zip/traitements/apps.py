from django.apps import AppConfig


class TraitementsConfig(AppConfig):
    name = 'traitements'
