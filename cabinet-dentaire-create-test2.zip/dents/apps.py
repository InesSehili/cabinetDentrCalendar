from django.apps import AppConfig


class DentsConfig(AppConfig):
    name = 'dents'
